const http = require('http')
const port = 8000;


// create a request handler

function requestHandler(req, res) {
    console.log(req.url);

    // how to i send response
    res.end('Gotcha !')
}

// creat http server
const server = http.createServer(requestHandler)


server.listen(port, function (err) {
    if (err) {
        console.log(err)
        return
    }
    console.log('Server is up and running on port', port)
})
